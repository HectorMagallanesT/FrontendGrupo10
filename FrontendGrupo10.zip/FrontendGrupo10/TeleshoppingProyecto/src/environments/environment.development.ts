export const environment = {
    endpoint: "https://localhost:7106/"
};

