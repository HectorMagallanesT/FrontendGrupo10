export interface Product {
    name: string;
    quantity: number;
    unitPrice: number;
  }