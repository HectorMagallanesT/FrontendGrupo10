import { Component } from "@angular/core";
import { RouterOutlet } from "@angular/router";
@Component({
    selector: 'app-cuerpo',
    standalone: true,
    templateUrl: './cuerpo.component.html',
    styleUrl: './cuerpo.component.css',
    imports: [RouterOutlet]
})
export class CuerpoComponent {


 
}