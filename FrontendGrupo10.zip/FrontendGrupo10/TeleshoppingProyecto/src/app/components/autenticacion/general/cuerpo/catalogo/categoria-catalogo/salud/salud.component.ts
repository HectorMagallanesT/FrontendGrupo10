import { Component } from '@angular/core';

@Component({
  selector: 'app-salud',
  standalone: true,
  imports: [],
  templateUrl: './salud.component.html',
  styleUrl: './salud.component.css'
})
export class SaludComponent {

}
