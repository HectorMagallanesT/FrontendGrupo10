import { Component } from '@angular/core';

@Component({
  selector: 'app-electronica',
  standalone: true,
  imports: [],
  templateUrl: './electronica.component.html',
  styleUrl: './electronica.component.css'
})
export class ElectronicaComponent {

}
