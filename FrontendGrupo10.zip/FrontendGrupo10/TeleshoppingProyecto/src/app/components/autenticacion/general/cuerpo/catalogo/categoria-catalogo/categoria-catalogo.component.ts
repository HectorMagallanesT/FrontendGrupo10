import { Component } from '@angular/core';

@Component({
  selector: 'app-categoria-catalogo',
  standalone: true,
  imports: [],
  templateUrl: './categoria-catalogo.component.html',
  styleUrl: './categoria-catalogo.component.css'
})
export class CategoriaCatalogoComponent {

}
