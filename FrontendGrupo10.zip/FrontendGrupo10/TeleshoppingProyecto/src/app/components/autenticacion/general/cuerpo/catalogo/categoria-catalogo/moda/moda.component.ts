import { Component } from '@angular/core';

@Component({
  selector: 'app-moda',
  standalone: true,
  imports: [],
  templateUrl: './moda.component.html',
  styleUrl: './moda.component.css'
})
export class ModaComponent {

}
