import { Component } from '@angular/core';

@Component({
  selector: 'app-moda-a',
  standalone: true,
  imports: [],
  templateUrl: './moda-a.component.html',
  styleUrl: './moda-a.component.css'
})
export class ModaAComponent {

}
