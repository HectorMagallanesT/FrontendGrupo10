import { Component } from '@angular/core';

@Component({
    selector: 'app-pie-admi',
    standalone: true,
    templateUrl: './pie-admi.component.html',
    styleUrl: './pie-admi.component.css',
    imports: []
})
export class PieAdmiComponent {

}
