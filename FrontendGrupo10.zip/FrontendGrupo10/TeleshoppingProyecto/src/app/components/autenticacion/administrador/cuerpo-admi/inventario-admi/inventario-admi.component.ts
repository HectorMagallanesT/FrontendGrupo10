import { Component } from '@angular/core';


@Component({
    selector: 'app-inventario-admi',
    standalone: true,
    templateUrl: './inventario-admi.component.html',
    styleUrl: './inventario-admi.component.css',
    imports: [ ]
})
export class InventarioAdmiComponent {
   
  
}
