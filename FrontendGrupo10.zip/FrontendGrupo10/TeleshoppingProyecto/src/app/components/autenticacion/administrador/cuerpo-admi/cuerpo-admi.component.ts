import { Component } from '@angular/core';

@Component({
  selector: 'app-cuerpo-admi',
  standalone: true,
  imports: [],
  templateUrl: './cuerpo-admi.component.html',
  styleUrl: './cuerpo-admi.component.css'
})
export class CuerpoAdmiComponent {

}
