import { Component } from '@angular/core';

@Component({
  selector: 'app-categoria-catalogo-admi',
  standalone: true,
  imports: [],
  templateUrl: './categoria-catalogo-admi.component.html',
  styleUrl: './categoria-catalogo-admi.component.css'
})
export class CategoriaCatalogoAdmiComponent {

}
