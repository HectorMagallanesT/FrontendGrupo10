import { Component } from '@angular/core';

@Component({
  selector: 'app-electronica-a',
  standalone: true,
  imports: [],
  templateUrl: './electronica-a.component.html',
  styleUrl: './electronica-a.component.css'
})
export class ElectronicaAComponent {

}
