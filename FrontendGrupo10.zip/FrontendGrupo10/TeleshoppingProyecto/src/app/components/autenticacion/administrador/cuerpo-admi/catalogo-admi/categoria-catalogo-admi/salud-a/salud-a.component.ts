import { Component } from '@angular/core';

@Component({
  selector: 'app-salud-a',
  standalone: true,
  imports: [],
  templateUrl: './salud-a.component.html',
  styleUrl: './salud-a.component.css'
})
export class SaludAComponent {

}
