export interface Proveedor {
    id?: number,
    nombre: string,
    origen: string,
    contacto: string,
}