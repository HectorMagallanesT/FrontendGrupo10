export interface Empresatransporte {
    id?: number;
    nombreEmpresa: String;
    ruc: String;
    correo: string;
    fechaRegistro: Date;
    telefono: string;
    estado: number;
}