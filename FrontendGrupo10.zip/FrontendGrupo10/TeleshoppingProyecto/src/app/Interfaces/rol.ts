export interface Rol{
    id?: number;
    usuario: string;
    password: string;
    confirmarPassword: string;

  }
  
