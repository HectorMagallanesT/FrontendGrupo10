export interface Usuario {
    id?: number;
    nombre: string;
    apellido: String;
    cedula: String;
    email: string;
    password: string;
    confirmarPassword: string;

  }
  
