export interface Compra{
    id?: number;
    nombre: string;
    cantidad: number;
    precioUnitario: number;
    precioTotal: number;
    estado: string
  }

 